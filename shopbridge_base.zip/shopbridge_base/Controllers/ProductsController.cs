﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Configuration;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        SqlConnection sqlConnection = null;
        SqlCommand sqlCommand = null;
        List<Product> Product = null;
        string DbConnectionString = "Data Source=DESKTOP-5GN882C\\SQLEXPRESS;Initial Catalog=InventoryMS;Integrated Security=True";
       
        public ProductsController(IProductService _productService)
        {
            this.productService = _productService;
        }

        [HttpGet]   
        public async Task<ActionResult<IEnumerable<Product>>> GetProduct()
        {
            Product = new List<Product>();
            try
            {
                sqlConnection = new SqlConnection(DbConnectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = "CreateCrudOperation"; //Stored Procedure Name
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Operation", "Select");
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    Product.Add(new Product
                    {
                        Product_Id = Convert.ToInt16(sqlDataReader["Product_Id"]),
                        Name = Convert.ToString(sqlDataReader["Name"]),
                        Price = Convert.ToDouble(sqlDataReader["Price"]),
                        Description = Convert.ToString(sqlDataReader["Description"])
                    });
                }
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            
            return Product;
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            Product products = new Product();
            try
            {
                sqlConnection = new SqlConnection(DbConnectionString);
                sqlConnection.Open();
                sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = "CreateCrudOperation";
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Operation", "SelectID");
                sqlCommand.Parameters.AddWithValue("@ID", id);
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    products = new Product
                    {
                        Product_Id = Convert.ToInt16(sqlDataReader["Product_Id"]),
                        Name = Convert.ToString(sqlDataReader["Name"]),
                        Price = Convert.ToDouble(sqlDataReader["Price"]),
                        Description = Convert.ToString(sqlDataReader["Description"])
                    };
                }
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return products;
        }

       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            try
            {
                sqlConnection = new SqlConnection(DbConnectionString);
                sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = "CreateCrudOperation";
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Operation", "Update");
                sqlCommand.Parameters.AddWithValue("@ID", id);
                sqlCommand.Parameters.AddWithValue("@Name", product.Name);
                sqlCommand.Parameters.AddWithValue("@Price", product.Price);
                sqlCommand.Parameters.AddWithValue("@Description", product.Description);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return NoContent();
        }

        
        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            try
            {
                sqlConnection = new SqlConnection(DbConnectionString);
                sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = "CreateCrudOperation";
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Operation", "Add");
                sqlCommand.Parameters.AddWithValue("@ID", product.Product_Id);
                sqlCommand.Parameters.AddWithValue("@Name", product.Name);
                sqlCommand.Parameters.AddWithValue("@Price", product.Price);
                sqlCommand.Parameters.AddWithValue("@Description", product.Description);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
            }
            catch (Exception)
            {

                throw;
            }
            return NoContent();
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                sqlConnection = new SqlConnection(DbConnectionString);
                sqlCommand = new SqlCommand();
                sqlCommand.Connection = sqlConnection;
                sqlCommand.CommandText = "CreateCrudOperation";
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@Operation", "Delete");
                sqlCommand.Parameters.AddWithValue("@ID", id);

                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
            }
            catch (Exception)
            {

                throw;
            }

            return NoContent();
        }

        private bool ProductExists(int id)
        {
            return false;
        }
    }
}
